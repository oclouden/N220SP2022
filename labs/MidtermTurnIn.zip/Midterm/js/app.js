//Owen Louden, Midterm, 3/1/22


//finds my div in HTML so I can interact with it

//create a function that is interacted with on a click
function div1Function(){

    //create variable to store information in newDiv1
    let newDiv1 = document.querySelector('#div1');

    //when clicked, find this element and change inner HTML

    document.getElementById("div1").innerHTML = "No";

}

//now how will I swap these values within the div?

//maybe if statement could help, like "if = Yes, change to No" and "else = No, change to Yes"

// if (div1 = 1) {
//     //then change to No, change to 0
// } else (div1 = 0) {
//     //change to Yes, change to 1
// }





