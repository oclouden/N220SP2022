//starting number
let displayNumber = 1000;

let clicked = document.getElementById("clickMe")

//function to carry out process
function lessenByTen() {
    //when clicked
   if(clicked) {

    //multiply the starting number by .10
    displayNumber * .10;


       event.target.innerHTML = results;
   }


}