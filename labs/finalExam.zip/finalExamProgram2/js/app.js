//starting number
let displayNumber = 1000;

let clicked = document.getElementById("clickMe")

//function to carry out process
function lessenByTen() {
   if(clicked) {
    displayNumber * .10;
        console.log(displayNumber)
   }


}