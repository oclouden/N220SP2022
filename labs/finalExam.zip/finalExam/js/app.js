//create an array

let arr = ["cars", "bikes", "vans", "trucks", "velocipedes"];


var arrayLength = arr.length;
for (var i = 1; i < arrayLength; i++) {
    
var results = document.getElementById('results');
results.innerHTML = arr;
}

